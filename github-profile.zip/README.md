<p align="center">
  <img src="./assets/profile-banner.svg" alt="Aditya Mohite — BS student at IIT Madras" width="100%" />
</p>

<br />

<div align="center">

### SOFTWARE · AI / ML · CYBERSECURITY

*Learning with purpose. Building things that matter.*

</div>

---

<table>
  <tr>
    <td width="72%" valign="middle">
      <h3>✦ THE LEAD</h3>
      <h2>Aditya Dipak Mohite</h2>
      <p>BS student at <strong>IIT Madras</strong>, learning to turn curiosity into useful technology.</p>
      <p>I'm building my foundations in problem solving and software development while exploring AI/ML and cybersecurity.</p>
    </td>
    <td width="28%" align="center" valign="middle">
      <strong>THE NORTH STAR</strong><br /><br />
      <code>LEARN → BUILD → IMPROVE</code>
    </td>
  </tr>
</table>

## ✦ THE STORY SO FAR

Technology interests me most when it moves beyond theory and becomes something useful. I'm working toward the skills to take an idea from a problem to a thoughtful, working product—and to keep learning along the way.

## ✦ CURRENTLY IN DEVELOPMENT

| Track | Focus |
|:--|:--|
| **Problem solving** | Data Structures & Algorithms; building strong fundamentals |
| **Intelligent systems** | Artificial Intelligence & Machine Learning |
| **Safer technology** | Cybersecurity |
| **Building in public** | Open source and software development |
| **From idea to impact** | Creating meaningful products that solve useful problems |

## ✦ THE LONG GAME

I want to become a strong problem solver and technology builder, combining software development with AI/ML and cybersecurity to create useful products.

> My goal isn't just to learn technologies—it's to use them to build things that matter.

## ✦ THE PRINCIPLES

<div align="center">

| 🧩 Stay curious | 🛠️ Build to learn | 🌍 Make it useful |
|:--:|:--:|:--:|
| Ask better questions | Turn ideas into practice | Keep people and real problems in view |

</div>

---

<div align="center">

**Keep learning. Keep building.**



</div>
